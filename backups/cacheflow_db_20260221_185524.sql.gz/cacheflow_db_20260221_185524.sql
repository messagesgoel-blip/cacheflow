--
-- PostgreSQL database dump
--

\restrict kG38LLgmQflbDQNlSkauPJNyVGzkcBlvFN5S6VQGU5igzqlzRigs5qhWfidr2oL

-- Dumped from database version 17.8
-- Dumped by pg_dump version 17.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cloud_configs; Type: TABLE; Schema: public; Owner: cacheflow
--

CREATE TABLE public.cloud_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    provider character varying(50) NOT NULL,
    config_json text NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.cloud_configs OWNER TO cacheflow;

--
-- Name: conflicts; Type: TABLE; Schema: public; Owner: cacheflow
--

CREATE TABLE public.conflicts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    file_path text NOT NULL,
    local_version_url text,
    cloud_version_url text,
    resolved boolean DEFAULT false,
    resolution_type character varying(50),
    detected_at timestamp without time zone DEFAULT now(),
    resolved_at timestamp without time zone
);


ALTER TABLE public.conflicts OWNER TO cacheflow;

--
-- Name: files; Type: TABLE; Schema: public; Owner: cacheflow
--

CREATE TABLE public.files (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    path text NOT NULL,
    size_bytes bigint NOT NULL,
    hash character varying(64),
    status character varying(20) DEFAULT 'pending'::character varying,
    last_modified timestamp without time zone,
    synced_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.files OWNER TO cacheflow;

--
-- Name: shared_links; Type: TABLE; Schema: public; Owner: cacheflow
--

CREATE TABLE public.shared_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    file_id uuid,
    token character varying(64) NOT NULL,
    password_hash character varying(255),
    expires_at timestamp without time zone,
    max_downloads integer,
    download_count integer DEFAULT 0,
    created_by uuid,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.shared_links OWNER TO cacheflow;

--
-- Name: users; Type: TABLE; Schema: public; Owner: cacheflow
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO cacheflow;

--
-- Data for Name: cloud_configs; Type: TABLE DATA; Schema: public; Owner: cacheflow
--

COPY public.cloud_configs (id, user_id, provider, config_json, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: conflicts; Type: TABLE DATA; Schema: public; Owner: cacheflow
--

COPY public.conflicts (id, user_id, file_path, local_version_url, cloud_version_url, resolved, resolution_type, detected_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: cacheflow
--

COPY public.files (id, user_id, path, size_bytes, hash, status, last_modified, synced_at, created_at) FROM stdin;
1f965f70-396f-40ee-ba99-eafaa960aa03	c94e8779-751b-444d-ae86-8bc1150fc664	/test/hello.txt	1024	\N	pending	\N	\N	2026-02-21 21:05:29.462754
9d4f3408-a1c4-4a80-8519-8ab294bd9c18	cd62dd3e-3018-4bbd-88dc-02e2bfb27142	/docs/report.pdf	51200	deadbeef	synced	\N	\N	2026-02-21 21:23:12.21892
733579e0-3633-4384-9389-28bae6a89597	c94e8779-751b-444d-ae86-8bc1150fc664	/auto-sync-test.txt	44	\N	synced	2026-02-21 21:26:03.252124	2026-02-21 21:26:06.089404	2026-02-21 21:25:33.266598
e60b6dbf-e755-48d1-b425-6c0a7a2abca6	c94e8779-751b-444d-ae86-8bc1150fc664	/pool-test.txt	0	\N	synced	2026-02-21 21:26:06.091963	2026-02-21 21:26:09.305705	2026-02-21 21:25:37.308424
caaa8630-65ac-43b7-b38f-0ed7b8d2e623	c94e8779-751b-444d-ae86-8bc1150fc664	/reboot-test.txt	46	\N	synced	2026-02-21 21:26:09.308208	2026-02-21 21:26:12.134498	2026-02-21 21:25:40.144381
4cd4b7c2-064d-4586-be2e-b1bbea170847	c94e8779-751b-444d-ae86-8bc1150fc664	/sync-test-1771709132.txt	0	\N	synced	2026-02-21 21:26:12.136418	2026-02-21 21:26:14.963574	2026-02-21 21:25:42.987669
4f477d8d-2bcc-4516-96b0-fcad67d96e0f	c94e8779-751b-444d-ae86-8bc1150fc664	/test.txt	46	\N	synced	2026-02-21 21:26:14.965975	2026-02-21 21:26:17.802145	2026-02-21 21:25:48.432703
88222ff0-36aa-4570-ae1a-3f845388dd91	c94e8779-751b-444d-ae86-8bc1150fc664	/test/file.txt	1024	\N	pending	\N	\N	2026-02-21 23:55:18.550038
\.


--
-- Data for Name: shared_links; Type: TABLE DATA; Schema: public; Owner: cacheflow
--

COPY public.shared_links (id, file_id, token, password_hash, expires_at, max_downloads, download_count, created_by, created_at) FROM stdin;
9f1248d6-f70e-421a-8d46-42f096c2daa8	1f965f70-396f-40ee-ba99-eafaa960aa03	test-token-abc123	\N	\N	\N	0	c94e8779-751b-444d-ae86-8bc1150fc664	2026-02-21 21:05:29.467489
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: cacheflow
--

COPY public.users (id, email, password_hash, created_at, updated_at) FROM stdin;
c94e8779-751b-444d-ae86-8bc1150fc664	sanjay@test.com	hashedpass123	2026-02-21 21:05:29.46011	2026-02-21 21:05:29.46011
cd62dd3e-3018-4bbd-88dc-02e2bfb27142	sanjay@cacheflow.local	$2b$12$HvaBDzqX7TehMIKpQhapYeJlz2oW9oKzqUOzC0gUmceBpvxnAXkbS	2026-02-21 21:21:02.339465	2026-02-21 21:21:02.339465
\.


--
-- Name: cloud_configs cloud_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: cacheflow
--

ALTER TABLE ONLY public.cloud_configs
    ADD CONSTRAINT cloud_configs_pkey PRIMARY KEY (id);


--
-- Name: conflicts conflicts_pkey; Type: CONSTRAINT; Schema: public; Owner: cacheflow
--

ALTER TABLE ONLY public.conflicts
    ADD CONSTRAINT conflicts_pkey PRIMARY KEY (id);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: cacheflow
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: files files_user_id_path_key; Type: CONSTRAINT; Schema: public; Owner: cacheflow
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_user_id_path_key UNIQUE (user_id, path);


--
-- Name: shared_links shared_links_pkey; Type: CONSTRAINT; Schema: public; Owner: cacheflow
--

ALTER TABLE ONLY public.shared_links
    ADD CONSTRAINT shared_links_pkey PRIMARY KEY (id);


--
-- Name: shared_links shared_links_token_key; Type: CONSTRAINT; Schema: public; Owner: cacheflow
--

ALTER TABLE ONLY public.shared_links
    ADD CONSTRAINT shared_links_token_key UNIQUE (token);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: cacheflow
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: cacheflow
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_conflicts_unresolved; Type: INDEX; Schema: public; Owner: cacheflow
--

CREATE INDEX idx_conflicts_unresolved ON public.conflicts USING btree (user_id, resolved);


--
-- Name: idx_files_modified; Type: INDEX; Schema: public; Owner: cacheflow
--

CREATE INDEX idx_files_modified ON public.files USING btree (last_modified DESC);


--
-- Name: idx_files_user_path; Type: INDEX; Schema: public; Owner: cacheflow
--

CREATE INDEX idx_files_user_path ON public.files USING btree (user_id, path);


--
-- Name: idx_files_user_status; Type: INDEX; Schema: public; Owner: cacheflow
--

CREATE INDEX idx_files_user_status ON public.files USING btree (user_id, status);


--
-- Name: idx_shared_links_token; Type: INDEX; Schema: public; Owner: cacheflow
--

CREATE INDEX idx_shared_links_token ON public.shared_links USING btree (token);


--
-- Name: cloud_configs cloud_configs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cacheflow
--

ALTER TABLE ONLY public.cloud_configs
    ADD CONSTRAINT cloud_configs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conflicts conflicts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cacheflow
--

ALTER TABLE ONLY public.conflicts
    ADD CONSTRAINT conflicts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: files files_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cacheflow
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: shared_links shared_links_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cacheflow
--

ALTER TABLE ONLY public.shared_links
    ADD CONSTRAINT shared_links_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: shared_links shared_links_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cacheflow
--

ALTER TABLE ONLY public.shared_links
    ADD CONSTRAINT shared_links_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict kG38LLgmQflbDQNlSkauPJNyVGzkcBlvFN5S6VQGU5igzqlzRigs5qhWfidr2oL

